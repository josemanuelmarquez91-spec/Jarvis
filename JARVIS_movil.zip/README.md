# JARVIS — versión móvil 1.0

Esta es una primera versión real de JARVIS que puedes abrir desde Android como una aplicación web instalable (PWA).

## Qué hace
- Chat con IA.
- Nombre y personalidad JARVIS.
- Guarda la conversación en la sesión del navegador.
- Botón de micrófono usando el reconocimiento de voz del navegador cuando está disponible.
- Lee las respuestas en voz alta.
- Diseño adaptado a móvil.
- Se puede instalar en la pantalla de inicio.

## Importante
La clave de OpenAI debe permanecer en el servidor, no dentro de `public/`.
No pegues tu clave en `app.js`.

## Cómo ponerlo en marcha
1. Instala Node.js en un ordenador o usa un entorno como Replit.
2. Copia `.env.example` a `.env`.
3. Pon tu clave en `OPENAI_API_KEY`.
4. Ejecuta:
   npm install
   npm start
5. Abre la dirección que te indique el servidor.

## Para usarlo desde el móvil
La opción más sencilla es desplegar este proyecto en un servicio que ejecute Node.js y te dé una URL HTTPS. Después abre esa URL en Chrome/Android y elige "Añadir a pantalla de inicio" o "Instalar aplicación".

## Próximas mejoras que podemos añadir
- Memoria permanente de José Manuel.
- Activación por voz tipo "Jarvis".
- Herramientas: tiempo, búsquedas, calendario, recordatorios, etc.
- Interfaz futurista.
- Voz más natural.
- Inicio de sesión.
- Base de datos para guardar recuerdos.
- Acciones reales del móvil cuando Android lo permita.
