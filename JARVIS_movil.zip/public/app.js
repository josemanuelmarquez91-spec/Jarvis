const chat = document.querySelector("#chat");
const form = document.querySelector("#form");
const input = document.querySelector("#input");
const mic = document.querySelector("#mic");
const status = document.querySelector("#status");
const clearBtn = document.querySelector("#clear");

let messages = JSON.parse(localStorage.getItem("jarvis_messages") || "[]");

function save() {
  localStorage.setItem("jarvis_messages", JSON.stringify(messages.slice(-40)));
}

function render() {
  chat.innerHTML = "";
  if (!messages.length) {
    addBubble("assistant", "Hola, José Manuel. Soy JARVIS. ¿En qué puedo ayudarte?");
    return;
  }
  for (const m of messages) addBubble(m.role, m.content);
}

function addBubble(role, text) {
  const div = document.createElement("div");
  div.className = `msg ${role}`;
  div.textContent = text;
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
}

async function send(text) {
  text = text.trim();
  if (!text) return;

  messages.push({ role:"user", content:text });
  addBubble("user", text);
  save();
  input.value = "";
  status.textContent = "JARVIS está pensando...";

  try {
    const r = await fetch("/api/chat", {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({ messages })
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || "Error");
    messages.push({ role:"assistant", content:data.reply });
    addBubble("assistant", data.reply);
    save();
    speak(data.reply);
    status.textContent = "Listo.";
  } catch (e) {
    addBubble("assistant", "Ha ocurrido un error al conectar con mi cerebro. Revisa el servidor y la clave de API.");
    status.textContent = "Error de conexión.";
  }
}

form.addEventListener("submit", e => {
  e.preventDefault();
  send(input.value);
});

clearBtn.addEventListener("click", () => {
  messages = [];
  save();
  render();
  status.textContent = "Nueva conversación.";
});

function speak(text) {
  if (!("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = "es-ES";
  u.rate = 1;
  speechSynthesis.speak(u);
}

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  const recognition = new SpeechRecognition();
  recognition.lang = "es-ES";
  recognition.interimResults = false;
  mic.addEventListener("click", () => {
    status.textContent = "Te escucho...";
    recognition.start();
  });
  recognition.onresult = e => {
    input.value = e.results[0][0].transcript;
    status.textContent = "Mensaje reconocido.";
    send(input.value);
  };
  recognition.onerror = () => status.textContent = "No he podido escucharte.";
} else {
  mic.disabled = true;
  mic.title = "Reconocimiento de voz no disponible en este navegador";
}

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("/sw.js").catch(() => {});
}

render();