import express from "express";
import OpenAI from "openai";

const app = express();
const port = process.env.PORT || 3000;

if (!process.env.OPENAI_API_KEY) {
  console.warn("Falta OPENAI_API_KEY. Configúrala como variable de entorno.");
}

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(express.json({ limit: "1mb" }));
app.use(express.static("public"));

app.post("/api/chat", async (req, res) => {
  try {
    const { messages } = req.body ?? {};

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "No hay mensajes." });
    }

    const cleanMessages = messages
      .filter(m => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
      .slice(-20);

    const response = await client.responses.create({
      model: "gpt-6-luna",
      instructions: `Tu nombre es JARVIS. Eres el asistente personal de José Manuel.
Responde en español, de forma natural, clara y útil.
Puedes decir que eres una IA creada por José Manuel.
No afirmes que puedes controlar el móvil, abrir aplicaciones o hacer acciones reales si la aplicación no te ha dado esa herramienta.
Cuando no sepas algo, dilo con honestidad.
Sé conciso salvo que José Manuel pida una explicación detallada.`,
      input: cleanMessages.map(m => ({
        role: m.role,
        content: m.content
      }))
    });

    res.json({ reply: response.output_text });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "No he podido conectar con JARVIS.",
      detail: process.env.NODE_ENV === "development" ? String(error) : undefined
    });
  }
});

app.listen(port, "0.0.0.0", () => {
  console.log(`JARVIS funcionando en http://localhost:${port}`);
});